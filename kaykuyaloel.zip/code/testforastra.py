import sys
import sqlite3
import json
import socket
import time
import hashlib
import uuid
from astrapy import DataAPIClient
from astrapy.constants import Environment
from PyQt5.QtWidgets import QSizePolicy,QListWidget,QDesktopWidget, QShortcut,QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit, QMessageBox, QTableWidget, QTableWidgetItem, QFormLayout, QRadioButton, QButtonGroup
from PyQt5.QtGui import QPixmap, QIcon, QKeySequence
from PyQt5.QtCore import Qt, QTimer

# Dictionary to store user accounts
users = {
    "admin": hashlib.sha256("admin".encode()).hexdigest()
}

# Database settings
ASTRA_DB_APPLICATION_TOKEN = "AstraCS:mZeTmGTuaCAyImDtWnGldsXn:b02f6f33102df559825a5c43d1c7b92741ed4363febaeda3beb343f1f3db7fe2"
ASTRA_DB_API_ENDPOINT = "https://61b56856-7f0d-4b96-8176-1d413d6f0d36-us-east1.apps.astra.datastax.com"

client = DataAPIClient(token=ASTRA_DB_APPLICATION_TOKEN)
database = client.get_database(ASTRA_DB_API_ENDPOINT)

# Initialize SQLite3 database
def init_db():
    conn = sqlite3.connect('manager.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS manager (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER NOT NULL,
            gender TEXT NOT NULL,
            address TEXT NOT NULL,
            email TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS changes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            operation TEXT NOT NULL,
            table_name TEXT NOT NULL,
            data TEXT NOT NULL,
            synced BOOLEAN NOT NULL DEFAULT 0
        )
    ''')
    cursor.execute('SELECT * FROM manager')
    if not cursor.fetchone():
        cursor.execute('INSERT INTO manager (name, email) VALUES (?, ?)', ("John Doe", "john.doe@example.com"))
    conn.commit()
    conn.close()

# Function to fetch manager details
def get_manager_details():
    conn = sqlite3.connect('manager.db')
    cursor = conn.cursor()
    cursor.execute('SELECT name, email FROM manager')
    manager = cursor.fetchone()
    conn.close()
    return manager

# Function to update manager details
def update_manager_details(name, email):
    conn = sqlite3.connect('manager.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE manager SET name = ?, email = ? WHERE id = 1', (name, email))
    conn.commit()
    conn.close()

# Function to add a new employee to both SQLite and Cassandra DB
def add_employee(name, age, gender, address, email):
    # Add employee to SQLite DB
    conn = sqlite3.connect('manager.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO employees (name, age, gender, address, email) VALUES (?, ?, ?, ?, ?)', (name, age, gender, address, email))
    conn.commit()

    # Log the change
    change_data = json.dumps({
        "name": name,
        "age": age,
        "gender": gender,
        "address": address,
        "email": email
    })
    cursor.execute('INSERT INTO changes (operation, table_name, data) VALUES (?, ?, ?)', ('add', 'employees', change_data))
    conn.commit()
    conn.close()

    # Add employee to Cassandra DB
    insert_employee_to_cassandra(name, age, gender, address, email)

# Function to insert employee data into Cassandra
def insert_employee_to_cassandra(name, age, gender, address, email):
    try:
        # Generate a unique UUID for the employee
        employee_id = str(uuid.uuid4())

        # Prepare the insert query
        collection = database.get_collection("employees_information")
        collection.insert_one({
            "id": employee_id,  # Include the generated UUID
            "name": name,
            "age": int(age),  # Ensure age is an integer
            "gender": gender,
            "address": address,
            "email": email
        })
        print("Employee inserted successfully into the cloud database.")
    except Exception as e:
        print(f"Error inserting employee into the cloud database: {e}")

# Function to fetch all employees
def get_all_employees():
    conn = sqlite3.connect('manager.db')
    cursor = conn.cursor()
    cursor.execute('SELECT name FROM employees')
    employees = [row[0] for row in cursor.fetchall()]
    conn.close()
    return employees

# Function to remove an employee
def remove_employee(name):
    try:
        # Fetch the employee ID from the cloud database
        collection = database.get_collection("employees_information")
        document = collection.find_one({"name": name})
        if document:
            employee_id = document["id"]
            # Delete the employee from the cloud database
            collection.delete_one({"id": employee_id})
            print(f"Employee {name} removed successfully from the cloud database.")
        else:
            print(f"Employee {name} not found in the cloud database.")
    except Exception as e:
        print(f"Error removing employee from the cloud database: {e}")

    # Delete the employee from the SQLite database
    conn = sqlite3.connect('manager.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM employees WHERE name = ?', (name,))
    conn.commit()
    conn.close()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("LOGIN")
        self.setGeometry(100, 100, 300, 200)
        self.layout = QVBoxLayout()
        self.layout.setSpacing(10)  # Add spacing between widgets
        self.layout.setAlignment(Qt.AlignCenter)  # Center-align the layout

        self.setWindowIcon(QIcon("icon.png"))

        self.username_label = QLabel("Username:")
        self.username_label.setStyleSheet("font-size: 20px; color: #050505;")
        self.layout.addWidget(self.username_label)
        self.username_entry = QLineEdit()
        self.layout.addWidget(self.username_entry)

        self.password_label = QLabel("Password:")
        self.password_label.setStyleSheet("font-size: 20px; color: #050505;")
        self.layout.addWidget(self.password_label)
        self.password_entry = QLineEdit()
        self.password_entry.setEchoMode(QLineEdit.Password)
        self.layout.addWidget(self.password_entry)

        self.login_button = QPushButton("Login")
        self.login_button.setStyleSheet("padding: 10px; font-size: 16px;")
        self.login_button.clicked.connect(self.login)
        self.layout.addWidget(self.login_button)

        self.enter_shortcut = QShortcut(QKeySequence(Qt.Key_Return), self)
        self.enter_shortcut.activated.connect(self.login_button.click)

        self.setLayout(self.layout)
        self.center()  # Center the window on the screen

    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def login(self):
        username = self.username_entry.text()
        password = self.password_entry.text()
        hashed_password = hash_password(password)
        if username in users and users[username] == hashed_password:
            QMessageBox.information(self, "Success", "Login successful!")
            self.close()
            self.main_window = MainWindow()
            self.main_window.show()
        else:
            QMessageBox.critical(self, "Error", "Invalid username or password.")
        self.username_entry.clear()
        self.password_entry.clear()

class RemoveEmployeeWindow(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Remove Employee")
        self.setGeometry(100, 100, 400, 300)
        self.layout = QVBoxLayout()

        self.employee_listbox = QListWidget()
        self.layout.addWidget(self.employee_listbox)

        self.remove_button = QPushButton("Remove Selected Employee")
        self.remove_button.clicked.connect(self.remove_selected_employee)
        self.layout.addWidget(self.remove_button)

        self.setLayout(self.layout)
        self.update_employee_list()

    def update_employee_list(self):
        self.employee_listbox.clear()
        employees = get_all_employees()
        for employee in employees:
            self.employee_listbox.addItem(employee)

    def remove_selected_employee(self):
        selected_index = self.employee_listbox.currentRow()
        if selected_index != -1:
            employee_name = self.employee_listbox.item(selected_index).text()
            self.close()
            self.main_window.confirm_remove_employee(employee_name)
        else:
            QMessageBox.critical(self, "Error", "Please select an employee to remove.")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.data_fetched = False  # Flag to track if data has been fetched
        self.initUI()
        

    def initUI(self):
        self.setWindowTitle("Main Page")
        self.setGeometry(100, 100, 1400, 600)  # Adjusted window size

        self.setStyleSheet("background-color: #0F2B56;")

        main_layout = QHBoxLayout()  # Use QHBoxLayout for the main layout

        # Left side layout
        left_layout = QVBoxLayout()
        left_layout.setSpacing(10)  # Adjust spacing as needed

        # Employee table
        self.employee_table = QTableWidget()
        self.employee_table.setStyleSheet("background-color: #000000")
        self.employee_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.employee_table.setSelectionMode(QTableWidget.NoSelection)
        self.employee_table.setColumnCount(5)
        self.employee_table.setHorizontalHeaderLabels(["Name", "Absences", "Lates", "Total Hours", "Email"])
        self.employee_table.setRowCount(0)
        self.employee_table.resizeColumnsToContents()
        self.employee_table.resizeRowsToContents()

        # Set column widths
        self.employee_table.setColumnWidth(0, 200)  # Name
        self.employee_table.setColumnWidth(1, 100)  # Absences
        self.employee_table.setColumnWidth(2, 100)  # Lates
        self.employee_table.setColumnWidth(3, 150)  # Total Hours
        self.employee_table.setColumnWidth(4, 250)  # Email

        # Calculate the total width needed for the columns
        total_column_width = sum([
            self.employee_table.columnWidth(0),
            self.employee_table.columnWidth(1),
            self.employee_table.columnWidth(2),
            self.employee_table.columnWidth(3),
            self.employee_table.columnWidth(4)
        ])

        # Set the width of the QTableWidget to fit all columns
        self.employee_table.setFixedWidth(total_column_width + 20)  # Add some extra space for padding

        # Set row height
        self.employee_table.verticalHeader().setDefaultSectionSize(30)

        # Enable alternating row colors with a different scheme
        self.employee_table.setStyleSheet("""
            QTableWidget {
                background-color: #FFFFFF;
                border: 1px solid #CCCCCC;
            }
            QTableWidget::item {
                border-bottom: 1px solid #CCCCCC;
            }
            QTableWidget::item:nth-child(even) {
                background-color: #F5F5F5;
            }
            QTableWidget::item:nth-child(odd) {
                background-color: #FFFFFF;
            }
        """)

        # Disable horizontal scrollbar
        self.employee_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        # Enable vertical scrollbar
        self.employee_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        # Set the size policy to expand and fill the available space
        self.employee_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # Add the table to the layout
        left_layout.addWidget(self.employee_table)

        # Right side layout for the logo, welcome label, and buttons
        right_layout = QVBoxLayout()
        right_layout.setSpacing(25)

        # Welcome label
        self.welcome_label = QLabel("Welcome to Zid Ratlook Employee Management!")
        self.welcome_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #4AAFF7; outline:5px #000000;")
        self.welcome_label.setAlignment(Qt.AlignCenter)
        right_layout.addWidget(self.welcome_label)
        import os
        # Logo label
        self.logo_label = QLabel()
        logo_path = "C:\\Users\\loel\\.vscode\\code\\the logo.png"  # Change this to the correct path if needed
        if os.path.exists(logo_path):
            pixmap = QPixmap(logo_path)
            if not pixmap.isNull():
                scaled_pixmap = pixmap.scaled(550, 280 , Qt.KeepAspectRatio)  # Scale the image
                self.logo_label.setPixmap(scaled_pixmap)
                self.logo_label.setAlignment(Qt.AlignCenter)  # Center the image
            else:
                self.logo_label.setText("Failed to load image")  # Fallback text if image fails to load
        else:
            self.logo_label.setText("Image file not found")  # Fallback text if file does not exist
        right_layout.addWidget(self.logo_label)

        # Buttons
        button_layout = QVBoxLayout()  # Create a QVBoxLayout for buttons
        button_layout.setSpacing(15)  # Adjust spacing as needed

        self.add_button = QPushButton("Add Employee")
        self.add_button.setStyleSheet("background-color: #F0E21D; color: white;")
        self.add_button.clicked.connect(self.add_employee)
        self.add_button.setFixedSize(550, 35)
        button_layout.addWidget(self.add_button)

        self.remove_button = QPushButton("Remove Employee")
        self.remove_button.clicked.connect(self.show_remove_employee_window)
        self.remove_button.setFixedSize(550, 35)
        button_layout.addWidget(self.remove_button)

        self.print_button = QPushButton("Print Attendance")
        self.print_button.clicked.connect(self.print_attendance)
        self.print_button.setFixedSize(550, 35)
        button_layout.addWidget(self.print_button)

        # Add the button layout to the right layout
        right_layout.addLayout(button_layout)

        # Add stretch factor to push the bottom buttons down
        right_layout.addStretch(1)

        # Bottom buttons layout
        bottom_layout = QHBoxLayout()
        self.modify_manager_button = QPushButton("Modify Manager")
        self.modify_manager_button.clicked.connect(self.modify_manager)
        self.modify_manager_button.setFixedSize(150, 35)
        bottom_layout.addWidget(self.modify_manager_button, 0)  # No stretch factor

        self.logout_button = QPushButton("Logout")
        self.logout_button.clicked.connect(self.logout)
        self.logout_button.setFixedSize(150, 35)
        bottom_layout.addStretch(1)  # Add stretch factor to push to the right
        bottom_layout.addWidget(self.logout_button, 0) 
                # Add bottom layout to the right layout
        right_layout.addLayout(bottom_layout)

        # Add left and right layouts to the main layout
        main_layout.addLayout(left_layout)
        main_layout.addLayout(right_layout)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.central_widget.setLayout(main_layout)

        # Fetch data only once when the app is first opened
        if not self.data_fetched:
            self.update_cloud_data()
            self.data_fetched = True

        # Start periodic sync
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.periodic_sync)
        self.timer.start(60000)  # Check every 60 seconds

    def update_cloud_data(self):
        try:
            # Fetch all documents from the employees_information collection
            employees_collection = database.get_collection("employees_information")
            employees = employees_collection.find({})

            # Fetch all documents from the attendance collection
            attendance_collection = database.get_collection("attendance")
            attendance_records = attendance_collection.find({})

            # Clear the existing items in the employee_table
            self.employee_table.setRowCount(0)

            # Create a dictionary to store attendance data for each employee
            attendance_data = {}
            for record in attendance_records:
                employee_name = record.get("employee_name")
                if employee_name not in attendance_data:
                    attendance_data[employee_name] = {
                        "absences": 0,
                        "lates": 0,
                        "total_hours": 0
                    }
                if record.get("status") == "absent":
                    attendance_data[employee_name]["absences"] += 1
                elif record.get("status") == "late":
                    attendance_data[employee_name]["lates"] += 1
                attendance_data[employee_name]["total_hours"] += record.get("hours_worked", 0)

            # Add the fetched employee details to the employee_table
            row = 0
            for doc in employees:
                name = doc.get("name", "Unknown Employee")
                absences = attendance_data.get(name, {}).get("absences", 0)
                lates = attendance_data.get(name, {}).get("lates", 0)
                total_hours = attendance_data.get(name, {}).get("total_hours", 0)
                email = doc.get("email", "Unknown Email")

                self.employee_table.insertRow(row)
                self.employee_table.setItem(row, 0, QTableWidgetItem(name))
                self.employee_table.setItem(row, 1, QTableWidgetItem(str(absences)))
                self.employee_table.setItem(row, 2, QTableWidgetItem(str(lates)))
                self.employee_table.setItem(row, 3, QTableWidgetItem(str(total_hours)))
                self.employee_table.setItem(row, 4, QTableWidgetItem(email))
                row += 1
        except Exception as e:
            print(f"Error fetching data from the cloud database: {e}")

    def show_remove_employee_window(self):
        self.remove_window = RemoveEmployeeWindow(self)
        self.remove_window.show()

    def confirm_remove_employee(self, employee_name):
        self.remove_window = QWidget()
        self.remove_window.setWindowTitle("Confirm Remove Employee")
        self.remove_window.setGeometry(100, 100, 400, 200)
        self.remove_layout = QVBoxLayout()

        self.username_label = QLabel("Username:")
        self.remove_layout.addWidget(self.username_label)
        self.username_entry = QLineEdit()
        self.remove_layout.addWidget(self.username_entry)

        self.password_label = QLabel("Password:")
        self.remove_layout.addWidget(self.password_label)
        self.password_entry = QLineEdit()
        self.password_entry.setEchoMode(QLineEdit.Password)
        self.remove_layout.addWidget(self.password_entry)

        self.confirm_button = QPushButton("Confirm Remove")
        self.confirm_button.clicked.connect(lambda: self.remove_employee(employee_name))
        self.remove_layout.addWidget(self.confirm_button)

        self.remove_window.setLayout(self.remove_layout)
        self.remove_window.show()

    def remove_employee(self, employee_name):
        username = self.username_entry.text()
        password = self.password_entry.text()
        hashed_password = hash_password(password)
        if username in users and users[username] == hashed_password:
            remove_employee(employee_name)
            QMessageBox.information(self, "Success", "Employee removed successfully!")
            self.remove_window.close()
            # Fetch data again after removing an employee
            self.update_cloud_data()
        else:
            QMessageBox.critical(self, "Error", "Invalid username or password.")
        self.username_entry.clear()
        self.password_entry.clear()

    def add_employee(self):
        self.add_window = QWidget()
        self.add_window.setWindowTitle("Add Employee")
        self.add_window.setGeometry(100, 100, 400, 400)
        self.add_layout = QFormLayout()
        self.add_layout.setSpacing(10)

        self.add_name_label = QLabel("Full Name:")
        self.add_entry = QLineEdit()
        self.add_layout.addRow(self.add_name_label, self.add_entry)

        self.add_age_label = QLabel("Age:")
        self.age_entry = QLineEdit()
        self.add_layout.addRow(self.add_age_label, self.age_entry)

        self.add_gender_label = QLabel("Gender:")
        self.gender_group = QButtonGroup()
        self.male_button = QRadioButton("Male")
        self.gender_group.addButton(self.male_button)
        self.female_button = QRadioButton("Female")
        self.gender_group.addButton(self.female_button)
        self.add_layout.addRow(self.add_gender_label, self.male_button)
        self.add_layout.addRow("", self.female_button)

        self.add_address_label = QLabel("Address:")
        self.address_entry = QLineEdit()
        self.add_layout.addRow(self.add_address_label, self.address_entry)

        self.add_email_label = QLabel("Email:")
        self.email_entry = QLineEdit()
        self.add_layout.addRow(self.add_email_label, self.email_entry)

        self.add_button = QPushButton("Add")
        self.add_button.clicked.connect(self.confirm_add)
        self.add_layout.addRow(self.add_button)

        self.add_window.setLayout(self.add_layout)
        self.add_window.show()

    def confirm_add(self):
        name = self.add_entry.text()
        age = self.age_entry.text()
        gender = "male" if self.male_button.isChecked() else "female"
        address = self.address_entry.text()
        email = self.email_entry.text()

        if name and age and gender and address and email:
            if QMessageBox.question(self, "Confirm", "Do you want to add this employee?") == QMessageBox.Yes:
                add_employee(name, age, gender, address, email)
                self.add_entry.clear()
                self.age_entry.clear()
                self.address_entry.clear()
                self.email_entry.clear()
                QMessageBox.information(self, "Success", "Employee added successfully!")
                self.add_window.close()
                # Fetch data again after adding an employee
                self.update_cloud_data()
        else:
            QMessageBox.critical(self, "Error", "Please fill all fields.")

    def print_attendance(self):
        # Get the list of employees from the employee_table
        employees = []
        for row in range(self.employee_table.rowCount()):
            row_data = []
            for column in range(self.employee_table.columnCount()):
                item = self.employee_table.item(row, column)
                if item:
                    row_data.append(item.text())
                else:
                    row_data.append("N/A")
            employees.append(row_data)

        if employees:
            attendance_message = "Attendance Report:\n" + "\n".join([" | ".join(employee) for employee in employees])
            QMessageBox.information(self, "Attendance", attendance_message)
        else:
            QMessageBox.information(self, "Attendance", "No employees to display.")

    def modify_manager(self):
        self.modify_window = QWidget()
        self.modify_window.setWindowTitle("Modify Manager")
        self.modify_window.setGeometry(100, 100, 300, 700)
        self.modify_layout = QVBoxLayout()
        self.modify_window.setStyleSheet("font-size: 24px; font-weight: bold; color: #050505;")

        manager_details = get_manager_details()
        self.name_label = QLabel("Manager Name:")
        self.modify_layout.addWidget(self.name_label)
        self.name_entry = QLineEdit(manager_details[0])
        self.modify_layout.addWidget(self.name_entry)

        self.email_label = QLabel("Manager Email:")
        self.modify_layout.addWidget(self.email_label)
        self.email_entry = QLineEdit(manager_details[1])
        self.modify_layout.addWidget(self.email_entry)

        self.save_button = QPushButton("Save")
        self.save_button.clicked.connect(self.confirm_modify)
        self.modify_layout.addWidget(self.save_button)

        self.modify_window.setLayout(self.modify_layout)
        self.modify_window.show()

    def confirm_modify(self):
        name = self.name_entry.text()
        email = self.email_entry.text()
        if name and email:
            try:
                # Fetch the manager ID from the cloud database
                collection = database.get_collection("manager_information")
                document = collection.find_one({"name": name})
                if document:
                    manager_id = document["id"]
                    # Update the manager's details in the cloud database
                    collection.update_one({"id": manager_id}, {"$set": {"name": name, "email": email}})
                    print(f"Manager {name} updated successfully in the cloud database.")
                else:
                    # Create a new document if the manager does not exist
                    manager_id = str(uuid.uuid4())
                    collection.insert_one({
                        "id": manager_id,
                        "name": name,
                        "email": email
                    })
                    print(f"Manager {name} created successfully in the cloud database.")
            except Exception as e:
                print(f"Error updating manager in the cloud database: {e}")

            # Update the manager's details in the SQLite database
            update_manager_details(name, email)
            QMessageBox.information(self, "Success", "Manager record updated successfully!")
            self.modify_window.close()
        else:
            QMessageBox.critical(self, "Error", "Please fill all fields.")

    def logout(self):
        self.close()
        self.login_window = LoginWindow()
        self.login_window.show()
        if hasattr(self, 'add_window') and self.add_window:
            self.add_window.close()

    def check_internet(self):
        try:
            # Try to connect to a known server (e.g., Google's DNS)
            socket.create_connection(("8.8.8.8", 53), 2)
            return True
        except OSError:
            return False

    def periodic_sync(self):
        if self.check_internet():
            self.sync_with_cloud()

    def sync_with_cloud(self):
        conn = sqlite3.connect('manager.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id, operation, table_name, data FROM changes WHERE synced = 0')
        changes = cursor.fetchall()

        for change in changes:
            change_id, operation, table_name, data = change
            data_dict = json.loads(data)

            if operation == 'add':
                if table_name == 'employees':
                    insert_employee_to_cassandra(data_dict['name'], data_dict['age'], data_dict['gender'], data_dict['address'], data_dict['email'])
            elif operation == 'update':
                # Implement update logic
                pass
            elif operation == 'delete':
                # Implement delete logic
                pass

            # Mark the change as synced
            cursor.execute('UPDATE changes SET synced = 1 WHERE id = ?', (change_id,))

        conn.commit()
        conn.close()

def main():
    app = QApplication(sys.argv)
    init_db()
    login_window = LoginWindow()
    login_window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
        